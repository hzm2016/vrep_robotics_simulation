class Environment:
    def __init__(self):
        pass

    def reset(self):
        pass

    def render(self):
        pass

    def step(self, action):
        pass

    def close(self):
        pass