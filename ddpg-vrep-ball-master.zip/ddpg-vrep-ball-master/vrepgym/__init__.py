
def make(envname):
    assert type(envname) is str

